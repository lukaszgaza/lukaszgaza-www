import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class SingletonTest {

    @Test
    public void shouldPass() {
        assertNotEquals(2, 3);
    }
}
