public class Singleton {
}
